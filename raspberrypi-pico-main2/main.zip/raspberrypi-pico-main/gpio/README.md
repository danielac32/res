GPIO basic

```
void gpio_init(uint gpio, uint func);
void gpio_dir(uint gpio, uint out);
void gpio_pullup(uint gpio, uint enable);
void gpio_pulldown(uint gpio, uint enable);
void gpio_set(uint gpio, uint value);
uint gpio_get(uint gpio);
```

Usage:

- make
- copy picobin.uf2 to rpi-pico



