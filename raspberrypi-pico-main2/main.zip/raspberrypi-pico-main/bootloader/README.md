Bootloader, XIP
