Systick timer

```
void systick_init();
void systick_deinit();
void systick_set(uint value);
uint systick_get();
```

Usage:

- make
- copy picobin.uf2 to rpi-pico
