#pragma once

void systick(uint ticks);
