SSI read from flash
