#pragma once
#include "rp2040.h"

void xosc_init();
void xosc_disable();
void xosc_dormant();
