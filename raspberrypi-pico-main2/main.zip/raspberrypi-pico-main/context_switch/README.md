Context switch


```
void task_init();
void task_create(void (*func)());
void task_yield();
void task_term();
```
