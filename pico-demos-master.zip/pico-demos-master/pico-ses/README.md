## Description

This is a sample RP2040 SEGGER Embedded Studio project that works with pico-debug.

## Limitations

- SEGGER Embedded Studio does not presently appear to support CMSIS-DAP directly.  However, it will work with OpenOCD, so this is the configuration option used in this sample project.

