#ifndef _PICO_H
#define _PICO_H

#include <stdint.h>
#include <stddef.h>

typedef  unsigned int uint;
 
#include <assert.h>
#define static_assert _Static_assert

#endif
