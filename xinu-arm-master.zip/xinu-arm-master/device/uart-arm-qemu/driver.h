void uart1Init(uint16_t baud, uint8_t mode, uint8_t fmode);
int uart1Putch(int ch);
int uart1GetchRTS(void);
